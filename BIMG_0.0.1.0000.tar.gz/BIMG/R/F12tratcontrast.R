#' @title Calcula os contrastes entre médias de amostras bootstrap,
#' indexadas por tratamentos.
#' 
#' @name trat.contrast
#'
#' @description Calcula os contrastes entre médias de amostras bootstrap,
#' indexadas por tratamentos, tomados dois a dois.
#' 
#' @param Mvalues Matriz de dimensao \code{I} por \code{B},
#' em que as linhas correspondem aos \code{I} tratamentos e as colunas
#' correspondem as porcentagens de inibicao do crescimento micelial dos
#' tratamentos em relacao ao controle, estimadas a partir das amostras
#' bootstrap de \code{MS.C} e \code{Mtrat}.
#' @param ID Vetor de identificacao para tratamentos
#' 
#' @details Calcula, dois a dois, a diferenca entre as medias de porcentagem
#' de inibicao do crescimento micelial para multiplos tratamentos.
#' O contraste e calculado pela diferenca entre as medias dos valores de PIC
#' para os tratamentos obtidos por meio das respectivas amostras bootstrap.
#' 
#' F-12 - trat.contrast Ultima edicao/atualizacao: 12/05/2022
#'
#' @return \code{Mcomp} : Matriz de dimensao \code{I!/((I-2)!*2!)} por \code{B},
#' em que I e o numero de tratamentos. 
#' As linhas correspondem aos constrastes entre as medias de PIC dos \code{I}
#' tratamentos, duas a duas,e as colunas
#' correspondem as amostras bootstrap das quais as medias foram calculadas.
#' 
#' @author Rodrigo D. Marques;
#'         Cristian M. V. Lobos.
#'
#' @seealso \code{\link[BIMG]{boot.pic1}}, 
#' \code{\link[BIMG]{boot.pic2}}, \code{\link[BIMG]{fMcomp}}
#'
#' @examples
#'#Parametros dos tratamentos e numero de repeticoes
#'Tmu <- c(0.85, 0.7, 0.5, 0.5, 0.85)
#'Tvar <- c(0.001, 0.001, 0.001, 0.001, 0.001)
#'Tid <- c("Control", "T1", "T2", "T3", "T4")
#'vn <- c(4,4,4,4,4)
#'Mpar <- fMpar(Tmu = Tmu, Tvar = Tvar, Tid = Tid)
#'
#'#Simulacao
#'#Geracao de bancos de dados
#'dados <- multi.ss(vn = vn, Mpar = Mpar, rdist = rbeta, nsample = 1)
#'
#'#Bootstrap
#'M <- boot.pic2(dados = dados, B = 5, nc = vn[1], print.matrixes = FALSE)
#'
#'#Calculando os contrastes
#'is.matrix(M[[1]])
#'trat.contrast(M[[1]], ID = dados[[1]]$id)
#'
#' @export
trat.contrast <- function (Mvalues, ID)
{
  trat.id <- levels(as.factor(ID))[-1]
  nc <- (length(trat.id))
  (A<-combn(nc,2))
  
  C <- matrix(0,ncol(A),ncol(Mvalues))
  for (i in 1:ncol(A)){
    C[i,] <- Mvalues[A[1,i],]-Mvalues[A[2,i],]
  }
  
  r.names <- NULL
  for (i in 1:ncol(A)){
    r.names[i] <- paste(trat.id[A[1,i]], "vs", trat.id [A[2,i]])
  }
  
  rownames(C) <- r.names
  colnames(C) <- c(paste("B", 1:ncol(C)))
  return(C)
}
