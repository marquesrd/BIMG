#' @title Calcula a PIC por meio de bootstrap, para multiplos bancos de dados
#' 
#' @name boot.pic2
#'
#' @description Calcula a porcentagem de inibicao do crescimento
#' micelial de tratamentos em relacao a um controle, por meio de bootstrap, para
#' multiplos bancos de dados. Util para estudos de simulacao.
#' 
#' @param dados Lista de data.frames, contendo vetor de identificacao dos
#' tratamentos e vetor numerico com diametro das colonias fungicas do controle
#' e dos tratamentos. Os dados referentes ao controle devem ser os primeiros
#' valores nos data.frames.
#' @param B Numero de amostras bootstrap a serem geradas.
#' @param nc Tamanho amostral do controle.
#' @param print.matrixes Logico. Se \code{print.matrixes==T}, retorna listas com
#' as matrizes \code{MB.C}, \code{MS.C}, \code{Mtrat} e \code{Mvalues},
#' em caso contrario, retorna apenas listas com as matrizes \code{Mvalues}.
#'
#' @details Calcula a porcentagem de inibicao do crescimento micelial de
#' tratamentos em relacao ao controle, por meio de bootstrap.
#' Generalizao da funcao \code{boot.pic1} para listas com multiplos bancos
#' de dados.
#' Reamostra com reposicao \code{n_i} elementos a partir do vetor
#' \code{x}, em que \code{n_i} e o tamanho amostral do tratamento \code{i},
#' gerando \code{B} amostras bootstrap independentes. A porcentagem de inibicao
#' do crescimento micelial e dada pela expressao PIC = 1 - Ti/Cm (FONTE, ANO).
#' 
#' F-09 - boot.pic2 Ultima edicao/atualizacao: 15/05/2022
#'
#' @return Retorna uma lista de matrizes para cada banco de dados,
#' constituidas por:
#' \code{MB.C} : Matriz de dimensao \code{B} por \code{n}, em que as linhas
#' correspondem as amostras bootstrap geradas a partir do vetor \code{Control}, 
#' contendo \code{n} elementos, dispostos nas colunas.
#'
#' \code{MS.C} : Matriz de dimensao 1 por \code{B}, em que as colunas correspondem
#' a estatistica de interesse estimada para cada amostra bootstrap.
#' 
#' \code{MTrat} : Lista de matrizes de dimensao \code{B} por \code{n_i},
#' em que as linhas correspondem as amostras bootstrap geradas
#' a partir dos \code{I} tratamentos, contendo \code{n_i} elementos,
#' dispostos nas colunas.
#'
#'\code{Mvalues} : Matriz de dimensao \code{I} por \code{B},
#' em que as linhas correspondem aos \code{I} tratamentos e as colunas
#' correspondem as porcentagens de inibicao do crescimento micelial dos
#' tratamentos em relacao ao controle, estimadas a partir das amostras
#' bootstrap de \code{MS.C} e \code{Mtrat}.
#' 
#' @author Rodrigo D. Marques;
#'         Cristian M. V. Lobos.
#'
#' @seealso \code{\link[BIMG]{bstrap}}, \code{\link[BIMG]{multi.ss}}, 
#' \code{\link[BIMG]{boot.pic1}}
#'
#' @examples
#'#Parametros dos tratamentos e numero de repeticoes
#'Tmu <- c(0.85, 0.7, 0.5, 0.5, 0.85)
#'Tvar <- c(0.001, 0.001, 0.001, 0.001, 0.001)
#'Tid <- c("Control", "T1", "T2", "T3", "T4")
#'vn <- c(4,4,4,4,4)
#'Mpar <- fMpar(Tmu = Tmu, Tvar = Tvar, Tid = Tid)
#'
#'#Simulacao
#'#Geracao de bancos de dados
#'dados <- multi.ss(vn = vn, Mpar = Mpar, rdist = rbeta, nsample = 10)
#'
#'#Bootstrap
#'M <- boot.pic2(dados = dados, B = 100, nc = vn[1], print.matrixes = TRUE)
#'
#' @export
boot.pic2 <- function(dados, B, nc, print.matrixes = F)
{
  aux <- list(NULL)
  for(i in 1:length(dados)){
    aux[[i]] <- boot.pic1 (dados[[i]]$Diam,
                           INDEX = dados[[i]]$id,
                           FUN = bstrap,
                           Control = dados[[i]]$Diam[1:nc],
                           B = B, 
                           print.matrixes = print.matrixes)
  }
  return(aux)
}