#' @title Determina a taxa de cobertura para intervalos de confianca
#' 
#' @name CoRa
#'
#' @description Determina a porcentagem de intervalos de confianca que contem o
#' parametro, alem do equilibrio entre as caudas inferior e superior em relacao
#' ao nivel de significancia. Suporta multiplas amostras.
#' 
#' @param CI Lista de matrizes de intervalos de confianca,
#' em que as linhas correspondem aos tratamentos,e as colunas
#' correspondem aos limites inferiores e superiores do intervalo de confianca,
#' respectivamente.
#' @param theta Numerico. Vetor de parametros referencia para determinar a 
#' taxa de cobertura.
#' @param print.matrixes Logico. Se \code{print.matrixes==T}, retorna listas com
#' as matrizes \code{Descricao}, \code{Lower.tail}, \code{Upper.tail},
#' \code{Cobertura} e \code{Taxa_cobertura}, 
#' em caso contrario, retorna apenas a matriz \code{Taxa_cobertura}.
#' 
#' @details A funcao atribui a cada replica de intervalo de confianca da lista
#' \code{CI} o valor \code{1} se o intervalo contem o parametro e o valor
#' \code{0} em caso contrario.
#' Quando o intervalo de confianca nao cobre o parametro, este ultimo pode estar
#' abaixo do limite inferior, portanto \code{theta<LI} recebe o valor \code{1}
#' ou acima do limite superior, portanto \code{theta<LS} recebe o valor \code{1}.
#' 
#' F-14 - CoRa Ultima edicao/atualizacao: 12/05/2022
#'
#' @return Lista com as seguintes matrizes:
#' 
#' \code{Descricao}: A cobertura, de forma detalhada, de cada intervalo de
#' confianca construido quanto a amplitude e as caudas.
#' 
#' \code{Lower.tail}: Identifica qual intervalo de confianca nao contem
#' o parametro pois este esta abaixo do limite inferior.
#' 
#' \code{Upper.tail}: Identifica qual intervalo de confianca nao contem
#' o parametro pois este esta acima do limite superior.
#' 
#' \code{Cobertura}: Identifica qual intervalo de confianca contem
#' o parametro pois este esta dentro da amplitude intervalar.
#' 
#' \code{Taxa_cobertura}: Matriz em que as colunas informam:
#' 
#' \code{%theta<LI}: A porcentagem de intervalos de confianca que nao contem
#' o parametro pois este esta abaixo do limite inferior.
#' 
#' \code{%LS<theta}: A porcentagem de intervalos de confianca que nao contem
#' o parametro pois este esta acima do limite superior.
#' 
#' \code{Taxa de Cobertura} A porcentagem de intervalos de confianca que contem
#' o parametro pois este esta dentro da amplitude intervalar.
#' 
#' @author Rodrigo D. Marques;
#'         Cristian M. V. Lobos.
#'
#' @seealso \code{\link[BIMG]{fMcomp}}, \code{\link[BIMG]{CI.boot}}
#'
#' @examples
#'#Parametros dos tratamentos e numero de repeticoes
#'Tmu <- c(0.85, 0.7, 0.5, 0.5, 0.85)
#'Tvar <- c(0.001, 0.001, 0.001, 0.001, 0.001)
#'Tid <- c("Control", "T1", "T2", "T3", "T4")
#'vn <- c(4,4,4,4,4)
#'
#'Mpar <- fMpar(Tmu = Tmu, Tvar = Tvar, Tid = Tid)
#'PICp <- fPICp(C = Tmu[1], Trat = Tmu[-1])
#'theta <- pic.contrast(PICp, ID = Tid)
#'
#'#Simulacao
#'#Geracao de bancos de dados
#'dados <- multi.ss(vn = vn, Mpar = Mpar, rdist = rbeta, nsample = 3)
#'
#'#Bootstrap
#'M <- boot.pic2(dados = dados, B = 5, nc = vn[1], print.matrixes = FALSE)
#'
#'#Calculando os contrastes
#'Mcomp <- fMcomp(Mvalues = M)
#'
#'#Construindo os intervalos de confianca e calculando as taxas de cobertura
#'IC <- CI.boot(Mcomp, alpha = 0.05)
#'
#'CoRa(IC, theta, print.matrixes = TRUE)
#'
#' @export
CoRa <- function(CI, theta, print.matrixes = F)
{
  IC <- CI
  A <- list(matrix(0, nrow = nrow(theta), ncol = 3,
                   dimnames = list(c(row.names(theta)),
                                   c("theta<LI", "LS<theta", "Contem theta"))))
  aux <- replicate(length(IC), A)
  for (j in 1:length(IC)){
    for (i in 1:nrow(theta)){
      aux[[j]][i,1] <- IC[[j]][i,1]>theta[i]
      aux[[j]][i,2] <- IC[[j]][i,2]<theta[i]
      aux[[j]][i,3] <- (((IC[[j]][i,1]<theta[i])*(IC[[j]][i,2]>theta[i])))
    }
  }
  
  LI <- matrix(0, nrow = nrow(theta), ncol = length(IC),
               dimnames = list(c(row.names(theta)),
                               paste("theta<LI", 1:length(IC))))
  for (j in 1:length(IC)){
    LI[,j] <- aux[[j]][,1]
  }
  
  LS <- matrix(0, nrow = nrow(theta), ncol = length(IC),
               dimnames = list(c(row.names(theta)),
                               paste("LS<theta", 1:length(IC))))
  for (j in 1:length(IC)){
    LS[,j] <- aux[[j]][,2]
  }
  
  Cob <- matrix(0, nrow = nrow(theta), ncol = length(IC),
                dimnames = list(c(row.names(theta)),
                                paste("Cobertura", 1:length(IC))))
  for (j in 1:length(IC)){
    Cob[,j] <- aux[[j]][,3]
  }
  
  TxCb1 <- round(as.matrix(apply(LI, MARGIN = 1, FUN = sum))*100/length(IC),2)
  TxCb2 <- round(as.matrix(apply(LS, MARGIN = 1, FUN = sum))*100/length(IC),2)
  TxCb3 <- round(as.matrix(apply(Cob, MARGIN = 1, FUN = sum))*100/length(IC),2)
  
  TxCb <- matrix(c(TxCb1, TxCb2, TxCb3), nrow = nrow(theta), ncol = 3,
                 dimnames = list(c(row.names(theta)),
                                 c("%theta<LI",
                                   "%LS<theta",
                                   "Taxa de Cobertura")))
  
  saidas <- list(Descricao = aux, Lower.tail = LI,
                 Upper.tail = LS, Cobertura = Cob,
                 Taxa_cobertura = TxCb)
  
  ifelse(print.matrixes==T, return(saidas), return(TxCb))
}
