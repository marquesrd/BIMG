#' @title Gera uma matriz de parametros "a" e "b"
#' da distribuicao beta para multiplos tratamentos.
#' 
#' @name fMpar
#'
#' @description Gera uma matriz, em que os parametros "a" e "b"
#' da distribuicao beta sao apresentadas respectivamente em duas colunas,
#' e as linhas correspondem aos multiplos tratamentos. 
#' 
#' @param Tmu Vetor de valores esperados de cada tratamento.
#' @param Tvar Vetor de variancias de cada tratamento.
#' @param Tid Vetor de identificacao para tratamentos.
#'
#' @details No contexto da simulacao, os vetores de valores esperados e
#' variancias sao conhecidos e escolhidos pelo usuario.
#' 
#' F-02 - fMpar Ultima edição/atualizacao: 12/05/2022
#' 
#' @return Uma matriz de parametros nao-negativos "a" e "b" da distribuicao beta
#' para multiplos tratamentos, com dimensao I por 2, em que I representa o
#' numero de tratamentos.
#'
#' @author Rodrigo D. Marques;
#'         Cristian M. V. Lobos. 
#'         
#' @examples
#' Tmu <- c(0.85, 0.7, 0.5, 0.5, 0.85)
#' Tvar <- c(0.001, 0.001, 0.001, 0.001, 0.001)
#' Tid <- c("Control", "T1", "T2", "T3", "T4")
#' 
#' (Mpar <- fMpar(Tmu = Tmu, Tvar = Tvar, Tid = Tid))
#'
#' @export
fMpar <- function(Tmu, Tvar, Tid)
{
  aux <- matrix(0, ncol = 2, nrow = length(Tmu),
                dimnames = list(c(Tid),
                                c("a","b")))
  
  for (i in 1:length(Tmu)){
    aux[i,1] <- beta.par(mu = Tmu[i], v = Tvar[i])$a
    aux[i,2] <- beta.par(mu = Tmu[i], v = Tvar[i])$b
  }
  return(aux)
}