#' @title Gera amostras pseudoaleatorias com valores de diametro de colonias
#' fungicas cultivadas em placas de Petri.
#' 
#' @name sample.simul
#'
#' @description Gera amostras pseudoaleatorias com valores de diametro
#' (em milimetros) de colonias fungicas cultivadas em placas de Petri.
#' A funcao suporta simulacoes para casos balanceados e nao balaceados.
#'
#' @param vn Vetor com numero de repeticoes de cada tratamento.
#' @param Mpar Matriz de parametros nao-negativos "a" e "b" da distribuicao beta.
#' @param rdist Distribuicao a ser utilizada no processo de simulacao, desde
#' que o modelo contenha um parametro de locacao e um parametro de escala.
#' @param PDD Diametro da placa de Petri, em milimetros. Default = 90 mm.
#' @param naprox Numero de casas decimais a serem mostradas na aproximacao.
#'
#' @details Caso particular da funcao \code{multi.ss}
#' 
#' F-03 - sample.simul Ultima edicao/atualizacao: 12/05/2022
#'
#' @return Data.frame em que nas colunas estao \code{id}: a identificacao dos
#' tratamentos;  \code{y}: os valores gerados a partir da distribuicao teorica;
#' e \code{Diam}: a conversao de \code{y} para diametro, em milimetros.
#'
#'
#' @author Rodrigo D. Marques;
#'         Cristian M. V. Lobos.
#'
#' @seealso \code{\link[stats]{rbeta}}, \code{\link[BIMG]{beta.par}},
#' \code{\link[BIMG]{fMpar}}, \code{\link[BIMG]{multi.ss}}
#'          
#'
#' @examples
#' #Parametros dos tratamentos e numero de repeticoes
#' Tmu <- c(0.85, 0.7, 0.5, 0.5, 0.85)
#' Tvar <- c(0.001, 0.001, 0.001, 0.001, 0.001)
#' Tid <- c("Control", "T1", "T2", "T3", "T4")
#' vn <- c(4,4,4,4,4)
#' 
#' #Matriz de parametros
#' Mpar <- fMpar(Tmu = Tmu, Tvar = Tvar, Tid = Tid)
#' 
#' #Simulacao
#' sample.simul(vn = vn, Mpar = Mpar, rdist = rbeta)
#' 
#' @export
sample.simul <- function(vn = vn, Mpar = Mpar, rdist, PDD = 90, naprox = 3)
{
  aux <- matrix(0, nrow = max(vn), ncol = length(vn))
  for (i in 1: length(vn)){
    aux[,i] <- round(c(rdist(vn[i], Mpar[i,1], Mpar[i,2]),
                       rep(NA,max(vn)-vn[i])),naprox)
  }
  id <- rep(c("Control", paste("T", 1:(length(vn)-1), sep="")), e=max(vn))
  y <- cbind(c(aux))
  return(na.omit(data.frame(id=id,y, Diam = y*PDD)))
}