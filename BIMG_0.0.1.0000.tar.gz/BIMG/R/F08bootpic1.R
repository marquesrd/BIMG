#' @title Calcula a PIC por meio de bootstrap
#' 
#' @name boot.pic1
#'
#' @description Calcula a porcentagem de inibicao do crescimento
#' micelial de tratamentos em relacao a um controle, por meio de bootstrap.
#' 
#' @param x Vetor numerico com dados referentes ao diametro das colonias fungicas
#' do controle e dos tratamentos.
#' @param INDEX Vetor de identificacao dos tratamentos.
#' @param FUN Funcao a ser aplicada ao vetor \code{x}.
#' @param Control Vetor numerico com dados referentes ao diametro das
#' colonias fungicas do controle.
#' @param B Numero de amostras bootstrap a serem geradas.
#' @param print.matrixes Logico. Se \code{print.matrixes==T}, retorna as matrizes
#' \code{MB.C}, \code{MS.C}, \code{Mtrat} e \code{Mvalues}, em caso contrario,
#' retorna apenas a matriz \code{Mvalues}.
#'
#' @details Calcula a porcentagem de inibicao do crescimento
#' micelial de tratamentos em relacao ao controle, por meio de bootstrap.
#' Reamostra com reposicao \code{n_i} elementos a partir do vetor
#' \code{x}, em que \code{n_i} e o tamanho amostral do tratamento \code{i},
#' gerando \code{B} amostras bootstrap independentes. A porcentagem de inibicao
#' do crescimento micelial e dada pela expressao PIC = 1 - Ti/Cm (FONTE, ANO).
#' 
#' F-08 - boot.pic1 Ultima edicao/atualizacao: 12/05/2022
#'
#' @return Retorna uma lista de matrizes, constituidas por:
#' \code{MB.C} : Matriz de dimensao \code{B} por \code{n}, em que as linhas
#' correspondem as amostras bootstrap geradas a partir do vetor \code{Control}, 
#' contendo \code{n} elementos, dispostos nas colunas.
#'
#' \code{MS.C} : Matriz de dimensao 1 por \code{B}, em que as colunas correspondem
#' a estatistica de interesse estimada para cada amostra bootstrap.
#' 
#' \code{MTrat} : Lista de matrizes de dimensao \code{B} por \code{n_i},
#' em que as linhas correspondem as amostras bootstrap geradas
#' a partir dos \code{I} tratamentos, contendo \code{n_i} elementos,
#' dispostos nas colunas.
#'
#'\code{Mvalues} : Matriz de dimensao \code{I} por \code{B},
#' em que as linhas correspondem aos \code{I} tratamentos e as colunas
#' correspondem as porcentagens de inibicao do crescimento micelial dos
#' tratamentos em relacao ao controle, estimadas a partir das amostras
#' bootstrap de \code{MS.C} e \code{Mtrat}.
#' 
#' @author Rodrigo D. Marques;
#'         Cristian M. V. Lobos.
#'
#' @seealso \code{\link[BIMG]{bstrap}}, \code{\link[BIMG]{boot.pic2}}
#'
#' @examples
#'Diam <- c(74.07, 75.69, 77.94, 81.00,
#'          65.79, 68.13, 61.47, 62.73,
#'          47.16, 50.76, 48.69, 43.83,
#'          48.10, 48.60, 47.52, 43.92,
#'          77.85, 76.68, 74.07, 74.25)
#'
#'id <- rep(c("Control", "T1", "T2", "T3", "T4"), e = 4)
#'
#'boot.pic1 (x = Diam, INDEX = id, FUN = bstrap,
#'           Control = Diam[1:4], B = 100, print.matrixes = TRUE)
#' @export
boot.pic1 <- function(x, 
                      INDEX,
                      FUN,
                      Control,
                      B,
                      print.matrixes = F)
{
  mod <- lm(x~INDEX)
  D <- model.matrix(mod)[-c(1:length(Control)),-1]
  ni <- as.vector(diag(t(D)%*%D))
  nt <- qr(D)$rank
  
  Y <- x[-c(1:length(Control))]
  FACTORS <- INDEX[-c(1:length(Control))]
  Mtrat <- tapply(Y, FACTORS, FUN, B)
  MB.C <- bstrap(Control, B)
  MS.C <- apply(MB.C, MARGIN = 1, FUN = mean)
  
  
  Mvalues <- matrix(0, nt, B)
  for (i in 1:nt){
    
    aux<- 1 - (Mtrat[[i]]/(matrix(c(rep(MS.C, each = ni[i])), 
                                  ncol = ni[i], byrow = T)))
    Mvalues[i,]<- apply(aux, 1, mean)
  }
  colnames(Mvalues) <- c(paste("B", 1:B))
  rownames(Mvalues) <- c(levels(as.factor(FACTORS)))
  saidas <- list(MB.C = MB.C, MS.C = MS.C, Mtrat = Mtrat, Mvalues = Mvalues)
  ifelse(print.matrixes==T, return(saidas), return(Mvalues))
}