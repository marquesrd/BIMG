#' @title Gera multiplos bancos de dados com amostras pseudoaleatorias de
#' valores de diametro de colonias fungicas cultivadas em placas de Petri.
#' 
#' @name multi.ss
#'
#' @description Gera multiplos bancos de dados com amostras pseudoaleatorias de
#' valores de diametro (em milimetros) de colonias fungicas cultivadas em placas
#' de Petri. A funcao suporta simulacoes para casos balanceados e nao balaceados.
#'
#' @param vn Vetor com numero de repeticoes de cada tratamento.
#' @param Mpar Matriz de parametros nao-negativos "a" e "b" da distribuicao beta.
#' @param rdist Distribuicao a ser utilizada no processo de simulacao, desde
#' que o modelo contenha um parametro de locacao e um parametro de escala.
#' @param nsample Numero de replicas de simulacao. Numero de bancos de dados
#' a serem simulados.
#' @param PDD Diametro da placa de Petri, em milimetros. Default = 90 mm.
#' @param naprox Numero de casas decimais a serem mostradas na aproximacao.
#'
#' @details Caso geral da funcao \code{multi.ss}, utilizado para estudos de
#' simulacao.
#' 
#' F-04 - multi.ss Ultima edicao/atualizacao: 12/05/2022
#'
#' @return Lista de data.frames em que nas colunas estao \code{id}: a
#' identificacao dos tratamentos;  \code{y}: os valores gerados a partir
#' da distribuicao teorica; e \code{Diam}: a conversao de \code{y} para
#' diametro, em milimetros.
#'
#'
#' @author Rodrigo D. Marques;
#'         Cristian M. V. Lobos.
#'
#' @seealso \code{\link[stats]{rbeta}}, \code{\link[BIMG]{beta.par}},
#'  \code{\link[BIMG]{fMpar}}, \code{\link[BIMG]{sample.simul}}
#'          
#'
#' @examples
#'#Parametros dos tratamentos e numero de repeticoes
#'Tmu <- c(0.85, 0.7, 0.5, 0.5, 0.85)
#'Tvar <- c(0.001, 0.001, 0.001, 0.001, 0.001)
#'Tid <- c("Control", "T1", "T2", "T3", "T4")
#'vn <- c(4,4,4,4,4)
#'
#'Mpar <- fMpar(Tmu = Tmu, Tvar = Tvar, Tid = Tid)
#'
#'#Geracao de bancos de dados
#'dados <- multi.ss(vn = vn, Mpar = Mpar, rdist = rbeta, nsample = 5)
#'
#' @export
multi.ss <- function(vn, Mpar, rdist = rbeta, nsample = 1, PDD = 90, naprox = 3)
{
  dados <- list(NULL)
  for (i in 1:nsample){
    dados[[i]] <- sample.simul(vn, Mpar, rdist, PDD = PDD, naprox = naprox)  
  }
  return(dados)
}