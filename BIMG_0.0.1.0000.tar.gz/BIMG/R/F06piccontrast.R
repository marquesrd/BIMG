#' @title Calcula o constraste entre PICs, dois a dois.
#' 
#' @name pic.contrast
#'
#' @description Calcula o contraste entre porcentagemns de inibicao do
#' crescimento micelial de multiplos tratamentos, tomados dois a dois.
#' 
#' @param PICp Vetor de porcentagens de inibicao do crescimento micelial para
#' multiplos tratamentos em relacao ao tratamento controle.
#' @param ID Vetor de identificacao dos tratamentos.
#'
#' @details Retorna os contrastes entre porcentagemns de inibicao do
#' crescimento micelial de multiplos tratamentos, tomados dois a dois, para 
#' fins de inferencia.
#' 
#' F-06 - pic.contrast Ultima edicao/atualizacao: 12/05/2022
#'
#' @return Vetor de contrastes entre porcentagemns de inibicao do
#' crescimento micelial de multiplos tratamentos, tomados dois a dois,
#' 
#'
#' @author Rodrigo D. Marques;
#'         Cristian M. V. Lobos.
#'
#' @seealso \code{\link[BIMG]{fPICp}}
#'
#' @examples
#'#Parametros dos tratamentos
#'Tmu <- c(0.85, 0.7, 0.5, 0.5, 0.85)
#'Tid <- c("Control", "T1", "T2", "T3", "T4")
#'
#'PICp <- fPICp(C = Tmu[1], Trat = Tmu[-1])
#'
#'(pic <- pic.contrast(PICp, ID = Tid))
#'
#' @export
pic.contrast <- function (PICp, ID)
{
  trat.id <- levels(as.factor(ID))[-1]
  nc <- (length(trat.id))
  (A<-combn(nc,2))
  
  C <- matrix(0, nrow = ncol(A))
  for (i in 1:ncol(A)){
    C[i,] <- PICp[A[1,i]]-PICp[A[2,i]]
  }
  
  r.names <- NULL
  for (i in 1:ncol(A)){
    r.names[i] <- paste(trat.id[A[1,i]], "vs", trat.id [A[2,i]])
  }
  
  rownames(C) <- r.names
  return(C)
}