#' @title Calcula a PIC a partir dos parametros conhecidos
#' para multiplos tratamentos.
#' 
#' @name fPICp
#'
#' @description Calcula a porcentagem de inibicao do crescimento
#' micelial a partir dos parametros conhecidos (utilizados na simulacao
#' das amostras) para multiplos tratamentos. A PIC e calculada
#' em relacao ao diametro do tratamento controle.
#'
#' @param C  Valor esperado, ou media, para o controle, a partir dos parametros
#' nao-negativos "a" e "b" da distribuicao beta.
#' @param Trat Vetor de valores esperados, ou medias, para os tratamentos,
#' a partir dos parametros nao-negativos "a" e "b" da distribuicao beta.
#'
#' @details Em estudos de simulacao, a porcentagem de inibicao do crescimento
#' micelial teorica, a partir de parametros conhecidos, pode ser utilizada como
#' referencia para as tecnicas de reamostragem.
#' 
#' F-05 - fPICp Ultima edicao/atualizacao: 12/05/2022
#'
#' @return Vetor de porcentagens de inibicao do crescimento micelial para
#' multiplos tratamentos em relacao ao tratamento controle.
#' 
#'
#' @author Rodrigo D. Marques;
#'         Cristian M. V. Lobos.
#'
#' @seealso \code{\link[stats]{rbeta}}, \code{\link[BIMG]{beta.par}}
#'
#' @examples
#'#Valores esperados dos tratamentos
#'Tmu <- c(0.85, 0.7, 0.5, 0.5, 0.85)
#'
#'(PICp <- fPICp(C = Tmu[1], Trat = Tmu[-1]))
#'
#'
#' @export
fPICp <- function(C, Trat)
{
  PICp <- NULL
  for(i in 1:length(Trat))
    PICp[i] <- round(1-Trat[i]/C,3)
  return(PICp)
}