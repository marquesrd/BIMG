#' @title Retorna os parametros "a" e "b" da distribuicao beta
#' a partir da media e variancia desejadas
#' 
#' @name beta.par
#'
#' @description Retorna os parametros "a" e "b" da distribuicao beta
#'   a partir da media e variancia desejadas. Os valores para media e variancia
#'   podem ser restritos a valores que gerem parametros que pertençam ao espaço
#'   parametrico (a>0, b>0).
#'
#' @param mu Valor esperado desejado da distribuicao beta.
#' @param v Variancia desejada da distribuicao beta.
#'
#' @details O valor esperado (ou media) da distribuicao beta deve ser um valor
#'   no intervalo (0,1). A variancia da distribuicao beta deve ser
#'   um valor positivo.
#' 
#' F-01 - beta.par Ultima edicao/atualizacao: 12/05/2022
#' 
#' #' Inserir referencias de como e a distribuicao beta, fdp, esperança 
#' e variancia, alem de como resolver o sistema.
#'
#' @return Os parametros \code{a} e \code{b} da distribuicao beta
#' a partir de valores de \code{mu} e \code{v} desejados e
#' informados como argumentos.
#'
#' @author Rodrigo D. Marques;
#'         Cristian M. V. Lobos; 
#'         Silvio S. Zocchi.
#'
#' @seealso \code{\link[base]{beta}}, \code{\link[stats]{rbeta}}
#'
#' @examples
#' beta.par(mu = -0.1, v = 0.01)
#' 
#' beta.par(mu = 1.1, v = 0.01)
#' 
#' beta.par(mu = 0.1, v = -0.01)
#' 
#' beta.par(mu = 0.1, v = 1)
#' 
#' beta.par(mu = 0.1, v = 0.01)
#'
#' @export
beta.par <- function(mu, v)
{
  ifelse(v>0,
      {
       #ifelse(mu==0, a <- 0, ifelse(mu==1, a <- 1, a <- -mu*(mu^2-mu+v)/v))
       #ifelse(mu==0, b <- 1, ifelse(mu==1, b <- 0, b <- (mu^2-mu+v)*(mu-1)/v))
        a <- -mu*(mu^2-mu+v)/v
        b <- (mu^2-mu+v)*(mu-1)/v 
      saidas <- list(a = a, b = b, mu = mu, v = v)
       ifelse(mu<0|mu>1, return("mu must be in (0,1) interval"),
              ifelse(a<0|b<0,
                     return("Parameters not in parameter space"),
                     return(saidas)))},
      return("v must be greater than 0"))
}
