#' @title Executa reamostragens para bootstrap
#' 
#' @name bstrap
#'
#' @description Executa reamostragens independentes, com reposicao,
#' para bootstrap.
#' 
#' @param x Vetor numerico.
#' @param B Numero de amostras bootstrap a serem geradas.
#'
#' @details Reamostra com reposicao \code{n} elementos a partir do vetor
#' \code{x}, em que \code{n} e o tamanho amostral de \code{x}, gerando \code{B}
#' amostras bootstrap independentes.
#' 
#' F-07 - bstrap Ultima edicao/atualizacao: 12/05/2022
#'
#' @return Retorna uma matriz, de dimensao \code{B} por \code{n}, em que cada
#' linha corresponde a uma amostra bootstrap, com os valores reamostrados
#' de \code{x} dispostos nas colunas.
#' 
#'
#' @author Rodrigo D. Marques;
#'         Cristian M. V. Lobos;
#'         Silvio S. Zocchi.
#'
#' @seealso \code{\link[modelr]{bootstrap}}
#'
#' @examples
#'x <- c(45, 40, 41, 42, 41)
#'
#'bstrap(x, B = 100)
#'
#' @export
bstrap <- function(x, B){
  n <- length(x)
  v <- sample(x, size = B*n, replace = T)
  MB <- matrix(v, nrow = B, ncol = n)
  return(MB)
}