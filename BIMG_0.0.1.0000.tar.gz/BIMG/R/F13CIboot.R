#' @title Calcula intervalos de confianca para multiplas amostras
#' 
#' @name CI.boot
#'
#' @description Calcula intervalos de confianca para mutiplas amostras
#' oriundas de bancos de dados independentes. Utilizada em estudos de simulacao
#' para determinar a taxa de cobertura de intervalos de confianca.
#' 
#' @param Mcomp Matriz de dimensao \code{I!/((I-2)!*2!)} por \code{B},
#' em que I e o numero de tratamentos para um determinado banco de dados. 
#' As linhas correspondem aos constrastes entre as medias de PIC dos \code{I}
#' tratamentos, duas a duas,e as colunas
#' correspondem as amostras boostrap das quais as medias foram calculadas.
#' @param alpha Numerico. Nivel de significancia dos intervalos de confianca,
#' de modo que o nivel de confianca e dado por 1-\code{alpha}.
#' \code{Default} = 0.05
#' 
#' @details Calcula, dois a dois, a diferenca entre as medias de porcentagem
#' de inibicao do crescimento micelial para multiplos tratamentos.
#' O contraste e calculado pela diferenca entre as medias dos valores de PIC
#' para os tratamentos obtidos por meio das respectivas amostras bootstrap.
#' 
#' F-13 - CI.boot Ultima edicao/atualizacao: 11/05/2022
#'
#' @return Lista de matrizes de dimensao \code{m} por \code{B},
#' em que m e o numero de linhas das matrizes \code{Mcomp} dos respectivos 
#' bancos de dados. 
#' As linhas correspondem aos tratamentos,e as colunas
#' correspondem aos limites inferiores e superiores do intervalo de confianca,
#' respectivamente.
#' 
#' @author Rodrigo D. Marques;
#'         Cristian M. V. Lobos.
#'
#' @seealso \code{\link[BIMG]{fMcomp}}
#'
#' @examples
#'#Parametros dos tratamentos e numero de repeticoes
#'Tmu <- c(0.85, 0.7, 0.5, 0.5, 0.85)
#'Tvar <- c(0.001, 0.001, 0.001, 0.001, 0.001)
#'Tid <- c("Control", "T1", "T2", "T3", "T4")
#'vn <- c(4,4,4,4,4)
#'Mpar <- fMpar(Tmu = Tmu, Tvar = Tvar, Tid = Tid)
#'
#'#Simulacao
#'#Geracao de bancos de dados
#'dados <- multi.ss(vn = vn, Mpar = Mpar, rdist = rbeta, nsample = 10)
#'
#'#Bootstrap
#'M <- boot.pic2(dados = dados, B = 5, nc = vn[1], print.matrixes = FALSE)
#'
#'#Calculando os contrastes
#'Mcomp <- fMcomp(Mvalues = M)
#'
#'IC <- CI.boot(Mcomp, alpha = 0.05)
#'
#' @export
CI.boot <- function(Mcomp, alpha = 0.05)
{
  (alphas <- c(alpha/2, 1-alpha/2))
  A <- list(matrix(0,nrow = nrow(Mcomp[[1]]), ncol=2,byrow = T,
                   dimnames = list(c(row.names(Mcomp[[1]])),
                                   c(paste(as.character(alphas), "%")))))
  
  aux <- replicate(length(Mcomp), A)
  for(j in 1:length(Mcomp)){
    for(i in 1:nrow(Mcomp[[1]])){
      aux[[j]][i,] <- quantile(Mcomp[[j]][i,],
                               probs=c(alphas))
    }
  }
  return(aux)
}