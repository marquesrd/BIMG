#' @title Calcula os contrastes entre medias de amostras boostrap,
#' indexadas por tratamentos, para multiplos bancos de dados.
#' 
#' @name fMcomp
#'
#' @description Calcula os contrastes entre medias de amostras boostrap,
#' indexadas por tratamentos, tomados dois a dois, para multiplos bancos de dados.
#' Generalizacao da funcao \code{trat.constrast}
#' 
#' @param Mvalues Lista de matrizes de dimensao \code{I} por \code{B},
#' em que as linhas correspondem aos \code{I} tratamentos e as colunas
#' correspondem as porcentagens de inibicao do crescimento micelial dos
#' tratamentos em relacao ao controle, estimadas a partir das amostras
#' bootstrap de \code{MS.C} e \code{Mtrat}.
#' 
#' @details Calcula, dois a dois, a diferenca entre as medias de porcentagem
#' de inibicao do crescimento micelial para multiplos tratamentos.
#' O contraste e calculado pela diferenca entre as medias dos valores de PIC
#' para os tratamentos obtidos por meio das respectivas amostras bootstrap.
#' 
#' F-11 - trat.contrast Ultima edicao/atualizacao: 12/05/2022
#'
#' @return \code{Mcomp}: Matriz de dimensao \code{I!/((I-2)!*2!)} por \code{B},
#' em que I e o numero de tratamentos para um determinado banco de dados. 
#' As linhas correspondem aos constrastes entre as medias de PIC dos \code{I}
#' tratamentos, duas a duas,e as colunas
#' correspondem as amostras boostrap das quais as medias foram calculadas.
#' 
#' @author Rodrigo D. Marques;
#'         Cristian M. V. Lobos.
#'
#' @seealso \code{\link[BIMG]{boot.pic1}}, 
#' \code{\link[BIMG]{boot.pic2}}, \code{\link[BIMG]{trat.contrast}}
#'
#' @examples
#'#Parametros dos tratamentos e numero de repeticoes
#'Tmu <- c(0.85, 0.7, 0.5, 0.5, 0.85)
#'Tvar <- c(0.001, 0.001, 0.001, 0.001, 0.001)
#'Tid <- c("Control", "T1", "T2", "T3", "T4")
#'vn <- c(4,4,4,4,4)
#'Mpar <- fMpar(Tmu = Tmu, Tvar = Tvar, Tid = Tid)
#'
#'#Simulacao
#'#Geracao de bancos de dados
#'dados <- multi.ss(vn = vn, Mpar = Mpar, rdist = rbeta, nsample = 10)
#'
#'#Bootstrap
#'M <- boot.pic2(dados = dados, B = 5, nc = vn[1], print.matrixes = FALSE)
#'
#'#Calculando os constrastes
#'fMcomp(Mvalues = M)
#'
#' @export
fMcomp <- function(Mvalues)
{
  Mcomp <- list(NULL)
  for(i in 1:length(Mvalues))
  {
    Mcomp[[i]] <- trat.contrast(Mvalues[[i]], ID = dados[[i]]$id) 
  }
  return(Mcomp)
}