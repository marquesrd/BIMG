#' @title Extrai a matriz \code{Mvalues} gerada pela funcao \code{boot.pic2}
#' 
#' @name M.extract
#'
#' @description Extrai a matriz \code{Mvalues}
#' da lista de matrizes gerada pela funcao \code{boot.pic2} quando o argumento
#' \code{print.matrixes} e indicado como \code{T}.
#' 
#' @param M Lista de matrizes gerada pela funcao \code{boot.pic2}.
#' 
#' @details Extrai, correspondente a cada banco dade dados, a matriz
#' \code{Mvalues} da lista de matrizes gerada pela funcao \code{boot.pic2}
#' quando o argumento \code{print.matrixes} e indicado como \code{T}.
#' Permite, sem a realizacao de nova reamostragem, 
#' que matrizes de interesse sejam copiadas da saida da funcao
#' \code{boot.pic2} para serem utilizadas em outras operacoes e funcoes. 
#' 
#' F-10 - M.extract Ultima edicao/atualizacao: 12/05/2022
#'
#' @return \code{Mvalues} : Matriz de dimensao \code{I} por \code{B},
#' em que as linhas correspondem aos \code{I} tratamentos e as colunas
#' correspondem as porcentagens de inibicao do crescimento micelial dos
#' tratamentos em relacao ao controle, estimadas a partir das amostras
#' bootstrap de \code{MS.C} e \code{Mtrat}.
#' 
#' @author Rodrigo D. Marques;
#'         Cristian M. V. Lobos.
#'
#' @seealso \code{\link[BIMG]{bstrap}}, \code{\link[BIMG]{multi.ss}}, 
#' \code{\link[BIMG]{boot.pic2}}
#'
#' @examples
#'#Parametros dos tratamentos e numero de repeticoes
#'Tmu <- c(0.85, 0.7, 0.5, 0.5, 0.85)
#'Tvar <- c(0.001, 0.001, 0.001, 0.001, 0.001)
#'Tid <- c("Control", "T1", "T2", "T3", "T4")
#'vn <- c(4,4,4,4,4)
#'Mpar <- fMpar(Tmu = Tmu, Tvar = Tvar, Tid = Tid)
#'
#'#Simulacao
#'#Geracao de bancos de dados
#'dados <- multi.ss(vn = vn, Mpar = Mpar, rdist = rbeta, nsample = 10)
#'
#'#Bootstrap
#'M <- boot.pic2(dados = dados, B = 100, nc = vn[1], print.matrixes = TRUE)
#'
#'#Extracao das matrizes de interesse
#'Mvalues <- M.extract(M)
#' @export
M.extract <- function(M)
{
  Mvalues <- list(NULL)
  for(i in 1:length(M)){
    Mvalues[[i]] <- M[[i]]$Mvalues
  }
  return(Mvalues)
}